﻿using Humanizer.Localisation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using pracmvc.Models;

namespace pracmvc.Controllers
{
    public class productController : Controller
    {
        OnlinestoresContext db = new OnlinestoresContext();
        public IActionResult IndexCategory()
        {
            return View(db.Categories.ToList());
        }
        public IActionResult IndexSupplier()
        {
            return View(db.Suppliers.ToList());
        }


        public IActionResult Index(string searchQuery, int? categoryId, int? supplierId, int page = 1, int pageSize = 6)
        {
            var booksQuery = db.Products
                .Include(b => b.Category)
                .Include(b => b.Supplier)
                .AsQueryable();

            if (!string.IsNullOrEmpty(searchQuery))
            {
                booksQuery = booksQuery.Where(b => b.ProductName.Contains(searchQuery) ||
                                                   b.Category.CategoryName.Contains(searchQuery) ||
                                                   b.Supplier.SupplierName.Contains(searchQuery));
            }

            if (categoryId.HasValue)
            {
                booksQuery = booksQuery.Where(b => b.CategoryId == categoryId.Value);
            }

            if (supplierId.HasValue)
            {
                booksQuery = booksQuery.Where(b => b.SupplierId == supplierId.Value);
            }

            var totalBooks = booksQuery.Count();
            var books = booksQuery
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            ViewBag.CurrentPage = page;
            ViewBag.TotalPages = (int)Math.Ceiling((double)totalBooks / pageSize);
            ViewBag.SearchQuery = searchQuery;
            ViewBag.CategoryId = new SelectList(db.Categories, "CategoryId", "CategoryName");
            ViewBag.SupplierId = new SelectList(db.Suppliers, "SupplierId", "SupplierName");


            return View(books);
        }

        public IActionResult CreateCategory()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CreateCategory(Category au)
        {
            if (ModelState.IsValid)
            {
                db.Categories.Add(au);
                db.SaveChanges();
                return RedirectToAction("IndexCategory");
            }
            else
            {

                return View();
            }
        }
        public IActionResult CreateSupplier()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CreateSupplier(Supplier gen)
        {
            if (ModelState.IsValid)
            {
                db.Suppliers.Add(gen);
                db.SaveChanges();
                return RedirectToAction("IndexSupplier");
            }
            else
            {

                return View();
            }
        }
        public IActionResult CreateProduct()
        {
            ViewBag.CategoryId = new SelectList(db.Categories, "CategoryId", "CategoryName");
            ViewBag.SupplierId = new SelectList(db.Suppliers, "SupplierId", "SupplierName");
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CreateProduct(Product boo, IFormFile file)
        {
            var imagename = DateTime.Now.ToString("yymmddmmss");
            imagename += Path.GetFileName(file.FileName);

            string imagepath = Path.Combine(HttpContext.Request.PathBase.Value, "wwwroot/Uploads");
            var imagevalue = Path.Combine(imagepath, imagename);

            using (var stream = new FileStream(imagevalue, FileMode.Create))
            {
                file.CopyTo(stream);
            }

            var dbimage = Path.Combine("/Uploads", imagename);
            boo.Image = dbimage;

            db.Products.Add(boo);
            db.SaveChanges();

            ViewBag.CategoryId = new SelectList(db.Categories, "CategoryId", "CategoryName");
            ViewBag.SupplierId = new SelectList(db.Suppliers, "SupplierId", "SupplierName");
            return RedirectToAction("Index");
        }
    }
}
